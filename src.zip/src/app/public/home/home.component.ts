import { Component } from '@angular/core';
import { HeaderComponent } from "../../layouts/header/header.component";
import { AboutComponent } from "./about/about.component";
import { NewsComponent } from "./news/news.component";
import { GalleryComponent } from "./gallery/gallery.component";
import { ContactUsComponent } from "./contact-us/contact-us.component";
import { BrowserModule } from '@angular/platform-browser';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  imports: [AboutComponent, NewsComponent, GalleryComponent, ContactUsComponent],
  templateUrl: './home.component.html',
  styleUrl: './home.component.css'
})
export class HomeComponent {
  constructor(private router: Router) {

  }
  gotoLink(link: string) {
    this.router.navigate([link]);
  }
}

import { ApplicationConfig, provideZoneChangeDetection } from '@angular/core';
import { provideRouter } from '@angular/router';

import { routes } from './app.routes';

// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries
// Your web app's Firebase configuration
 const firebaseConfig = {
  apiKey: "AIzaSyB6SM1LDTYFfW0Ws1fEHN5h9vAevXe44P8",
  authDomain: "akkar-hunting-club.firebaseapp.com",
  projectId: "akkar-hunting-club",
  storageBucket: "akkar-hunting-club.firebasestorage.app",
  messagingSenderId: "1022978166336",
  appId: "1:1022978166336:web:854519950e2bbe00b099a5",
  measurementId: "G-9DDD12FDWK"
};
// Initialize Firebase
 const app = initializeApp(firebaseConfig);
 const analytics = getAnalytics(app);;
export const appConfig: ApplicationConfig = {
  providers: [provideZoneChangeDetection({ eventCoalescing: true }), provideRouter(routes)]
};

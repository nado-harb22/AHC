import { Routes } from '@angular/router';
import { HomeComponent } from './public/home/home.component';
import { LoginComponent } from './public/login/login.component';
import { authGuard } from './shared/guard/auth.guard';
import { SignupComponent } from './public/signup/signup.component';
import { AboutComponent } from './public/home/about/about.component';

export const routes: Routes = [
    {
        path: 'home',
        component: HomeComponent,
        canActivate: [authGuard]
    },
    {
        path: '',
        component: LoginComponent
    },
    {
        path: 'signup',
        component: SignupComponent
    },

    {
        path: 'about',
        component: AboutComponent
    }
];

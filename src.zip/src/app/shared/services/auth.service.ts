import { Injectable } from '@angular/core';
import { getAnalytics } from '@firebase/analytics';
import { initializeApp } from 'firebase/app';
import { getAuth, onAuthStateChanged, signInWithEmailAndPassword, signOut, User } from 'firebase/auth';
const firebaseConfig = {
  apiKey: "AIzaSyB6SM1LDTYFfW0Ws1fEHN5h9vAevXe44P8",
  authDomain: "akkar-hunting-club.firebaseapp.com",
  projectId: "akkar-hunting-club",
  storageBucket: "akkar-hunting-club.firebasestorage.app",
  messagingSenderId: "1022978166336",
  appId: "1:1022978166336:web:854519950e2bbe00b099a5",
  measurementId: "G-9DDD12FDWK"
};
// Initialize Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);;
// Initialize Firebase Auth
const auth = getAuth(app);

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  user: User | null = null;
  
  constructor() {
    onAuthStateChanged(auth, user => {
      this.user = user;
    });
  }

  async login(email: string, password: string) {
    return signInWithEmailAndPassword(auth, email, password);
  }

  async logout() {
    return signOut(auth);
  }

  isAuthenticated(): boolean {
    return this.user !== null;
  }
}

